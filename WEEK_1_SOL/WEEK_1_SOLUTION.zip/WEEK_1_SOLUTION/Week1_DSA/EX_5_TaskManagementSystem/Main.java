package Week1DSA.TaskManagement;

public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskLinkedList = new TaskLinkedList();
        taskLinkedList.run();
    }
}