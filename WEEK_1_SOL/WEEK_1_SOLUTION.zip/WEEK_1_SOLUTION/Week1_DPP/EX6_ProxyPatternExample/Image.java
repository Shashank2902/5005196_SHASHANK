package Week1DPP.ProxyPatternExample;

public interface Image {
    void display();
}