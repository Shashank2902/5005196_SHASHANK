package Week1DPP.StrategyPatternExample;

// PaymentStrategy.java
public interface PaymentStrategy {
    void pay(int amount);
}