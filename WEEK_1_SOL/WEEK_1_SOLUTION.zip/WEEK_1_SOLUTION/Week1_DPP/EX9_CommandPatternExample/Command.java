package Week1DPP.CommandPatternExample;

// Define the Command interface with a method execute()
public interface Command {
    void execute();
}
