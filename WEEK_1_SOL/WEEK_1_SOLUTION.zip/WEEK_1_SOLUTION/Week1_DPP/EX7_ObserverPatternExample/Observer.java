package Week1DPP.ObserverPatternExample;

// Define Observer Interface
public interface Observer {
    void update(String stockPrice);
}
