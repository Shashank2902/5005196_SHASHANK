package Week1DPP.AdapterPatternExample;

// PaymentProcessor.java
public interface PaymentProcessor {
    void processPayment(String paymentDetails);
}
