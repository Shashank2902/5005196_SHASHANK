package Week1DPP.DecoratorPatternExample;

// Define Component Interface
public interface Notifier {
    void send(String message);
}
